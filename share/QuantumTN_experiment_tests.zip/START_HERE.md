# QuantumTN experiment package

Start with reports/BASIS_AND_ROUTING_TESTS.md for the new X/Z hardware tests, distance-5 routing comparison and offline re-decoding results.
The included normalized archive indexes 72 distinct measured IQM jobs and 564,000 hardware shots. Several analyses may refer to the same job or the same shots.

Read README_WINDOWS.md to install dependencies. Open START_IQM_DASHBOARD.cmd from this extracted folder to explore the archived measurements and simulations offline.
Run dashboard/audit_distance5.py with the project Python environment to replay both distance-5 audits. No IQM account is needed to inspect results. Historical scripts that import the other team's qec package need that separate dependency for re-execution.

Find the two new jobs in research_data/distance_3/basis_pilot and research_data/distance_5/routing_followup. The first d5 pilot is in research_data/distance_5/routed_hardware.
For older job files, look up the original results path in research_data/distance_3/manifest.json, then resolve its file field relative to research_data/distance_3.
MANIFEST.sha256 lists the digest of each included file (except the manifest itself).
